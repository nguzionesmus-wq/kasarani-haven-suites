import { useState } from "react";
import { Mail, CheckCircle } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";

export function NewsletterSubscribe() {
  const [email, setEmail] = useState("");
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      // In a real application, this would send to your email service
      console.log("Subscribing email:", email);
      setIsSubscribed(true);
      setEmail("");
      
      // Reset after 5 seconds
      setTimeout(() => setIsSubscribed(false), 5000);
    }
  };

  return (
    <section className="py-16 bg-gradient-to-r from-orange-500 to-orange-600">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <div className="mb-6">
            <Mail className="w-12 h-12 text-white mx-auto mb-4" />
            <h2 className="mb-4 text-white">
              Subscribe to Our Blog
            </h2>
            <p className="text-orange-100 text-lg">
              Get the latest travel tips, local guides, and exclusive offers
              delivered straight to your inbox. Stay updated with Kasarani Haven
              Suites!
            </p>
          </div>

          {isSubscribed ? (
            <div className="bg-white rounded-lg p-6 flex items-center justify-center gap-3 animate-in fade-in duration-500">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <p className="text-gray-900">
                Thank you for subscribing! Check your email for confirmation.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-xl mx-auto">
              <Input
                type="email"
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="flex-1 bg-white border-white text-gray-900 placeholder:text-gray-500 h-12"
              />
              <Button
                type="submit"
                className="bg-gray-900 hover:bg-gray-800 text-white h-12 px-8"
              >
                Subscribe
              </Button>
            </form>
          )}

          <p className="text-orange-100 mt-4">
            We respect your privacy. Unsubscribe at any time.
          </p>
        </div>
      </div>
    </section>
  );
}
