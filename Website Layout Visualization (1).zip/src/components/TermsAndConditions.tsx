import { FileText, X } from "lucide-react";
import { Button } from "./ui/button";

interface TermsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function TermsModal({ isOpen, onClose }: TermsModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <FileText className="w-6 h-6 text-orange-500" />
            <h2 className="text-gray-900">Terms & Conditions</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="overflow-y-auto p-6 space-y-6">
          <div>
            <h3 className="mb-3 text-gray-900">1. Booking & Reservations</h3>
            <p className="text-gray-600">
              All bookings must be confirmed via WhatsApp or phone call.
              Reservations are subject to availability. A deposit may be
              required to secure your booking. Full payment is required upon
              check-in unless otherwise agreed.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">2. Check-in & Check-out</h3>
            <p className="text-gray-600 mb-2">
              <strong>Check-in time:</strong> Anytime (as long as the property is unoccupied)
              <br />
              <strong>Check-out time:</strong> By 12:00 PM (Noon)
            </p>
            <p className="text-gray-600">
              Flexible check-in available based on availability. Please contact us
              in advance to arrange your arrival time. Valid identification is
              required at check-in.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">3. Cancellation Policy</h3>
            <p className="text-gray-600">
              • Cancellations made 7+ days before check-in: Full refund minus
              10% processing fee
              <br />
              • Cancellations made 3-6 days before check-in: 50% refund
              <br />
              • Cancellations made less than 3 days before check-in: No refund
              <br />• No-shows: No refund
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">4. House Rules</h3>
            <ul className="text-gray-600 space-y-2">
              <li>• No smoking inside the property</li>
              <li>• No parties or events without prior approval</li>
              <li>• Maximum occupancy: 4 guests</li>
              <li>• Respect quiet hours (10:00 PM - 7:00 AM)</li>
              <li>• Guests are responsible for any damages or losses</li>
              <li>• Pets are not allowed unless pre-approved</li>
            </ul>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">5. Payment Terms</h3>
            <p className="text-gray-600">
              Accepted payment methods include M-Pesa, bank transfer, and cash.
              The nightly rate is KSh 3,000. Discounts are available for stays
              of 5 nights or more. All rates are subject to change without prior
              notice.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">6. Guest Responsibilities</h3>
            <p className="text-gray-600">
              Guests are expected to keep the property clean and treat it with
              respect. Any damages or missing items will be charged to the
              guest. Please report any issues immediately to management.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">7. Liability</h3>
            <p className="text-gray-600">
              Kasarani Haven Suites is not liable for any loss, theft, or damage
              to guests' personal belongings. We recommend securing travel
              insurance. The property is not responsible for any injuries
              sustained on the premises.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">8. Privacy & Data Protection</h3>
            <p className="text-gray-600">
              We respect your privacy and handle all personal information in
              accordance with Kenyan data protection laws. Guest information is
              used solely for booking purposes and will not be shared with third
              parties without consent.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">9. Force Majeure</h3>
            <p className="text-gray-600">
              Kasarani Haven Suites is not liable for any failure to perform
              obligations due to circumstances beyond our control, including but
              not limited to natural disasters, government restrictions, or other
              unforeseen events.
            </p>
          </div>

          <div>
            <h3 className="mb-3 text-gray-900">10. Contact Information</h3>
            <p className="text-gray-600">
              For questions about these terms and conditions, please contact us:
              <br />
              <strong>Phone:</strong> +254 727 832649
              <br />
              <strong>Email:</strong> info@kasaranihavensuites.com
              <br />
              <strong>Address:</strong> Clayworks, Kasarani, Nairobi
            </p>
          </div>

          <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
            <p className="text-gray-700">
              <strong>Last Updated:</strong> November 12, 2025
            </p>
            <p className="text-gray-600 mt-2">
              By booking with Kasarani Haven Suites, you acknowledge that you
              have read, understood, and agree to these terms and conditions.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200">
          <Button
            onClick={onClose}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white"
          >
            I Understand
          </Button>
        </div>
      </div>
    </div>
  );
}

export function TermsSection() {
  return (
    <section id="terms" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <FileText className="w-12 h-12 text-orange-500 mx-auto mb-4" />
            <h2 className="mb-4 text-gray-900">Terms & Conditions</h2>
            <p className="text-gray-600">
              Please read our terms and conditions carefully before booking your
              stay
            </p>
          </div>

          <div className="bg-gray-50 rounded-xl p-8 space-y-6">
            <div>
              <h3 className="mb-3 text-gray-900">1. Booking & Reservations</h3>
              <p className="text-gray-600">
                All bookings must be confirmed via WhatsApp or phone call.
                Reservations are subject to availability. A deposit may be
                required to secure your booking.
              </p>
            </div>

            <div>
              <h3 className="mb-3 text-gray-900">2. Check-in & Check-out</h3>
              <p className="text-gray-600">
                Check-in: Anytime (as long as the property is unoccupied) | Check-out: By 12:00 PM (Noon). Valid
                identification required at check-in.
              </p>
            </div>

            <div>
              <h3 className="mb-3 text-gray-900">3. Cancellation Policy</h3>
              <p className="text-gray-600">
                7+ days: Full refund minus 10% fee | 3-6 days: 50% refund | Less
                than 3 days: No refund
              </p>
            </div>

            <div>
              <h3 className="mb-3 text-gray-900">4. House Rules</h3>
              <p className="text-gray-600">
                No smoking indoors, maximum 4 guests, respect quiet hours (10 PM
                - 7 AM), guests responsible for damages.
              </p>
            </div>

            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <p className="text-gray-700">
                For complete terms and conditions, please contact us at{" "}
                <a
                  href="tel:+254727832649"
                  className="text-orange-600 hover:underline"
                >
                  +254 727 832649
                </a>{" "}
                or{" "}
                <a
                  href="mailto:info@kasaranihavensuites.com"
                  className="text-orange-600 hover:underline"
                >
                  info@kasaranihavensuites.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}