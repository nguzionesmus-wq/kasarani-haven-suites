import { useState } from "react";
import { Calendar } from "./ui/calendar";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { CalendarDays, Users, MessageCircle } from "lucide-react";

export function BookingCalendar() {
  const [checkIn, setCheckIn] = useState<Date | undefined>(undefined);
  const [checkOut, setCheckOut] = useState<Date | undefined>(undefined);
  const [guests, setGuests] = useState(2);

  const calculateNights = () => {
    if (checkIn && checkOut) {
      const nights = Math.ceil(
        (checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)
      );
      return nights > 0 ? nights : 0;
    }
    return 0;
  };

  const calculateTotal = () => {
    const nights = calculateNights();
    const pricePerNight = 3000;
    const total = nights * pricePerNight;
    
    // Apply discount for 5+ nights
    if (nights >= 5) {
      return { total, discount: true };
    }
    return { total, discount: false };
  };

  const handleBookNow = () => {
    const nights = calculateNights();
    const { total, discount } = calculateTotal();
    
    let message = `Hi, I would like to book Kasarani Haven Suites\n\n`;
    
    if (checkIn) {
      message += `Check-in: ${checkIn.toLocaleDateString()}\n`;
    }
    if (checkOut) {
      message += `Check-out: ${checkOut.toLocaleDateString()}\n`;
    }
    if (nights > 0) {
      message += `Nights: ${nights}\n`;
      message += `Guests: ${guests}\n`;
      message += `Estimated Total: KSh ${total.toLocaleString()}`;
      if (discount) {
        message += ` (5+ nights discount applicable!)`;
      }
    }

    const whatsappUrl = `https://wa.me/254727832649?text=${encodeURIComponent(
      message
    )}`;
    window.open(whatsappUrl, "_blank");
  };

  return (
    <section id="booking" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Check Availability & Book</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Select your dates and book your stay at the best Airbnb in Kasarani
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Calendar Selection */}
            <Card className="p-6">
              <div className="space-y-6">
                <div>
                  <label className="flex items-center gap-2 mb-3 text-gray-700">
                    <CalendarDays className="w-5 h-5 text-orange-500" />
                    <span>Check-in Date</span>
                  </label>
                  <Calendar
                    mode="single"
                    selected={checkIn}
                    onSelect={setCheckIn}
                    disabled={(date) => date < new Date()}
                    className="rounded-md border"
                  />
                </div>

                <div>
                  <label className="flex items-center gap-2 mb-3 text-gray-700">
                    <CalendarDays className="w-5 h-5 text-orange-500" />
                    <span>Check-out Date</span>
                  </label>
                  <Calendar
                    mode="single"
                    selected={checkOut}
                    onSelect={setCheckOut}
                    disabled={(date) =>
                      date < new Date() || (checkIn ? date <= checkIn : false)
                    }
                    className="rounded-md border"
                  />
                </div>
              </div>
            </Card>

            {/* Booking Summary */}
            <div className="space-y-6">
              <Card className="p-6">
                <h3 className="mb-4 text-gray-900">Booking Details</h3>

                <div className="space-y-4">
                  <div className="flex items-center gap-3 pb-4 border-b border-gray-200">
                    <Users className="w-5 h-5 text-orange-500" />
                    <div className="flex-1">
                      <label className="text-gray-700">Number of Guests</label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setGuests(Math.max(1, guests - 1))}
                        disabled={guests <= 1}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center">{guests}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setGuests(Math.min(4, guests + 1))}
                        disabled={guests >= 4}
                      >
                        +
                      </Button>
                    </div>
                  </div>

                  {checkIn && (
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600">Check-in:</span>
                      <span>{checkIn.toLocaleDateString()}</span>
                    </div>
                  )}

                  {checkOut && (
                    <div className="flex justify-between py-2">
                      <span className="text-gray-600">Check-out:</span>
                      <span>{checkOut.toLocaleDateString()}</span>
                    </div>
                  )}

                  {calculateNights() > 0 && (
                    <>
                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">Number of nights:</span>
                        <span>{calculateNights()}</span>
                      </div>

                      <div className="flex justify-between py-2">
                        <span className="text-gray-600">
                          KSh 3,000 × {calculateNights()} nights:
                        </span>
                        <span>
                          KSh {calculateTotal().total.toLocaleString()}
                        </span>
                      </div>

                      {calculateTotal().discount && (
                        <div className="bg-green-50 text-green-700 p-3 rounded-lg">
                          🌿 5+ nights discount applicable! Contact us for
                          special rates.
                        </div>
                      )}

                      <div className="border-t border-gray-200 pt-4 mt-4">
                        <div className="flex justify-between items-center mb-4">
                          <span className="text-gray-900">
                            Estimated Total:
                          </span>
                          <span className="text-orange-600">
                            KSh {calculateTotal().total.toLocaleString()}
                          </span>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </Card>

              <Button
                size="lg"
                onClick={handleBookNow}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Book via WhatsApp
              </Button>

              <div className="text-center text-gray-600">
                <p>
                  Or call us directly at{" "}
                  <a
                    href="tel:+254727832649"
                    className="text-orange-600 hover:underline"
                  >
                    +254 727 832649
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
