import { Bed, UtensilsCrossed, Car, Wifi, Shirt, Wine, Droplet, Tv } from "lucide-react";

const amenities = [
  {
    icon: Bed,
    title: "1-Bedroom Apartment",
    description: "Spacious and comfortable",
  },
  {
    icon: UtensilsCrossed,
    title: "Kitchen Access",
    description: "Fully equipped for cooking",
  },
  {
    icon: Car,
    title: "Free Parking",
    description: "Secure parking available",
  },
  {
    icon: Wifi,
    title: "Fast Wi-Fi",
    description: "High-speed internet",
  },
  {
    icon: Shirt,
    title: "Laundry Mart Nearby",
    description: "Convenient laundry services",
  },
  {
    icon: Wine,
    title: "Bar & Restaurant Next Door",
    description: "Dining at your doorstep",
  },
  {
    icon: Droplet,
    title: "Toiletries Provided",
    description: "All essentials included",
  },
  {
    icon: Tv,
    title: "Smart TV",
    description: "Entertainment ready",
  },
];

export function Amenities() {
  return (
    <section id="amenities" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">
            Everything You Need for a Comfortable Stay
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            We've thought of everything to make your stay as comfortable and
            convenient as possible.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {amenities.map((amenity, index) => {
            const Icon = amenity.icon;
            return (
              <div
                key={index}
                className="bg-gradient-to-br from-orange-50 to-white p-6 rounded-xl border border-orange-100 hover:shadow-lg hover:border-orange-300 transition-all duration-300 group"
              >
                <div className="w-12 h-12 bg-orange-500 rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="mb-2 text-gray-900">{amenity.title}</h3>
                <p className="text-gray-600">{amenity.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
