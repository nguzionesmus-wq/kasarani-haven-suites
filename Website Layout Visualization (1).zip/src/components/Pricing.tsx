import { DollarSign, Calendar, MessageCircle } from "lucide-react";
import { Button } from "./ui/button";

export function Pricing() {
  return (
    <section id="pricing" className="py-20 bg-gradient-to-br from-orange-50 to-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Affordable Comfort</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Quality accommodation at competitive rates. Book longer and save
            more.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
            <div className="bg-gradient-to-r from-orange-500 to-orange-600 text-white p-8 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <DollarSign className="w-8 h-8" />
                <span className="text-5xl">KSh 3,000</span>
              </div>
              <p className="text-xl text-orange-100">per night</p>
            </div>

            <div className="p-8">
              <div className="grid md:grid-cols-2 gap-6 mb-8">
                <div className="flex items-start gap-4 p-4 bg-orange-50 rounded-lg">
                  <Calendar className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="mb-2 text-gray-900">Extended Stay Discount</h3>
                    <p className="text-gray-600">
                      Save on stays of 5 nights or more. Contact us for special
                      long-term rates.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 bg-orange-50 rounded-lg">
                  <MessageCircle className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="mb-2 text-gray-900">Easy Booking</h3>
                    <p className="text-gray-600">
                      Book instantly via WhatsApp. Quick responses and
                      confirmations guaranteed.
                    </p>
                  </div>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-6">
                <h3 className="mb-4 text-center text-gray-900">
                  Ready to Book Your Stay?
                </h3>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a
                    href="https://wa.me/254727832649?text=Hi,%20I%20would%20like%20to%20book%20Kasarani%20Haven%20Suites"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 sm:flex-none"
                  >
                    <Button
                      size="lg"
                      className="w-full bg-green-600 hover:bg-green-700 text-white rounded-full px-8"
                    >
                      Book via WhatsApp
                    </Button>
                  </a>
                  <a
                    href="tel:+254727832649"
                    className="flex-1 sm:flex-none"
                  >
                    <Button
                      size="lg"
                      variant="outline"
                      className="w-full border-orange-500 text-orange-600 hover:bg-orange-50 rounded-full px-8"
                    >
                      Call Us
                    </Button>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
