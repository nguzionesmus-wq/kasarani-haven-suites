import { MapPin, DollarSign, Car } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { HERO_IMAGES, SITE_CONFIG } from "../data/content";

export function Hero() {
  // Use the first hero image from content.ts
  const heroImage = HERO_IMAGES[0];

  return (
    <section id="home" className="relative min-h-screen pt-64">
      {/* Background Image */}
      <div className="absolute inset-0">
        <ImageWithFallback
          src={heroImage.src}
          alt={heroImage.alt}
          className="w-full h-full object-cover object-center"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30"></div>
      </div>

      {/* Content */}
      <div className="relative container mx-auto px-4 min-h-screen flex items-center">
        <div className="max-w-3xl text-white pt-20 pb-20">
          <h1 className="mb-4 text-white">{SITE_CONFIG.siteName}</h1>
          <p className="text-xl md:text-2xl mb-6 text-orange-400">
            {SITE_CONFIG.slogan}
          </p>

          <div className="space-y-3 mb-8">
            <div className="flex items-start gap-3">
              <MapPin className="w-5 h-5 text-orange-400 flex-shrink-0 mt-1" />
              <p className="text-lg">
                Near bar, restaurant, shops & laundry mart
              </p>
            </div>
            <div className="flex items-start gap-3">
              <DollarSign className="w-5 h-5 text-orange-400 flex-shrink-0 mt-1" />
              <p className="text-lg">
                From KSh 3,000/night | 🌿 Discount after 5 days
              </p>
            </div>
            <div className="flex items-start gap-3">
              <Car className="w-5 h-5 text-orange-400 flex-shrink-0 mt-1" />
              <p className="text-lg">Only 15 minutes to Nairobi CBD</p>
            </div>
          </div>

          <a
            href={`https://wa.me/${SITE_CONFIG.phone.replace(/\s+/g, '')}?text=Hi,%20I%20would%20like%20to%20book%20Kasarani%20Haven%20Suites`}
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button
              size="lg"
              className="bg-orange-500 hover:bg-orange-600 text-white rounded-full px-8 py-6"
            >
              Book Now via WhatsApp
            </Button>
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
        </div>
      </div>
    </section>
  );
}