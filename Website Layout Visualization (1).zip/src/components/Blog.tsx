import { useState } from "react";
import { Calendar, User, ArrowRight } from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { RestaurantBlogPost } from "./RestaurantBlogPost";

// You can add your blog posts here
const blogPosts = [
  {
    id: 1,
    title: "Best Restaurants to Relax Around Nairobi at Affordable Prices",
    excerpt:
      "Discover the top affordable restaurants near Kasarani where you can enjoy delicious meals without breaking the bank. From traditional Kenyan cuisine to international favorites.",
    author: "Kasarani Haven Team",
    date: "November 12, 2025",
    image: "https://images.unsplash.com/photo-1730250619893-91982f0519b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlyb2JpJTIwcmVzdGF1cmFudCUyMGRpbmluZ3xlbnwxfHx8fDE3NjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
    tags: ["Food & Dining", "Budget-Friendly", "Local Guide"],
    fullPost: true,
  },
  {
    id: 2,
    title: "Top 10 Things to Do Near Kasarani Haven Suites",
    excerpt:
      "From local restaurants to shopping centers, explore the best attractions and activities within walking distance of our property.",
    author: "Kasarani Haven Team",
    date: "November 5, 2025",
    image: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?w=800",
    tags: ["Activities", "Local Guide"],
    fullPost: false,
  },
  {
    id: 3,
    title: "5 Reasons to Choose Kasarani Haven Suites for Your Business Trip",
    excerpt:
      "Learn why business travelers prefer our fully furnished apartments over traditional hotels for their Nairobi stays.",
    author: "Kasarani Haven Team",
    date: "October 28, 2025",
    image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800",
    tags: ["Business Travel", "Tips"],
    fullPost: false,
  },
];

export function Blog() {
  const [selectedPost, setSelectedPost] = useState<number | null>(null);

  if (selectedPost === 1) {
    return <RestaurantBlogPost onBack={() => setSelectedPost(null)} />;
  }

  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Latest from Our Blog</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Stay updated with travel tips, local guides, and news about the best
            Airbnb in Kasarani
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-8">
          {blogPosts.map((post) => (
            <Card
              key={post.id}
              className="overflow-hidden hover:shadow-xl transition-shadow duration-300 group"
            >
              <div className="aspect-[16/10] overflow-hidden">
                <ImageWithFallback
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              <div className="p-6">
                <div className="flex flex-wrap gap-2 mb-3">
                  {post.tags.map((tag, index) => (
                    <span
                      key={index}
                      className="text-xs bg-orange-100 text-orange-600 px-2 py-1 rounded-full"
                    >
                      {tag}
                    </span>
                  ))}
                </div>

                <h3 className="mb-3 text-gray-900 line-clamp-2">
                  {post.title}
                </h3>

                <p className="text-gray-600 mb-4 line-clamp-3">
                  {post.excerpt}
                </p>

                <div className="flex items-center gap-4 text-gray-500 mb-4 pb-4 border-b border-gray-200">
                  <div className="flex items-center gap-1">
                    <User className="w-4 h-4" />
                    <span className="text-xs">{post.author}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-xs">{post.date}</span>
                  </div>
                </div>

                {post.fullPost ? (
                  <Button
                    variant="ghost"
                    className="text-orange-600 hover:text-orange-700 p-0 h-auto group"
                    onClick={() => setSelectedPost(post.id)}
                  >
                    Read Full Article
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                ) : (
                  <Button
                    variant="ghost"
                    className="text-orange-600 hover:text-orange-700 p-0 h-auto group"
                    disabled
                  >
                    Coming Soon
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <p className="text-gray-600">More articles coming soon!</p>
        </div>
      </div>
    </section>
  );
}