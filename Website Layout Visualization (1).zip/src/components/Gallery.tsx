import { useState } from "react";
import { X, Play } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { GALLERY_ITEMS } from "../data/content";

export function Gallery() {
  const [selectedItem, setSelectedItem] = useState<number | null>(null);

  return (
    <section id="gallery" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Explore Our Space</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Take a virtual tour of our beautifully furnished apartment. Every
            corner is designed for your comfort and convenience.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {GALLERY_ITEMS.map((item, index) => (
            <div
              key={index}
              className="group relative aspect-[4/3] overflow-hidden rounded-xl cursor-pointer shadow-lg hover:shadow-xl transition-all duration-300"
              onClick={() => setSelectedItem(index)}
            >
              {item.type === "image" ? (
                <ImageWithFallback
                  src={item.src}
                  alt={item.caption}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              ) : (
                <div className="relative w-full h-full bg-black">
                  <ImageWithFallback
                    src={item.thumbnail}
                    alt={item.caption}
                    className="w-full h-full object-cover opacity-70 group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 bg-orange-500 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Play className="w-8 h-8 text-white ml-1" fill="white" />
                    </div>
                  </div>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 right-4">
                  <p className="text-white">{item.caption}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Modal for Image/Video */}
      {selectedItem !== null && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedItem(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-orange-400 transition-colors"
            onClick={() => setSelectedItem(null)}
          >
            <X className="w-8 h-8" />
          </button>
          <div className="max-w-5xl w-full">
            {GALLERY_ITEMS[selectedItem].type === "image" ? (
              <>
                <ImageWithFallback
                  src={GALLERY_ITEMS[selectedItem].src as string}
                  alt={GALLERY_ITEMS[selectedItem].caption}
                  className="w-full h-auto rounded-lg"
                />
                <p className="text-white text-center mt-4">
                  {GALLERY_ITEMS[selectedItem].caption}
                </p>
              </>
            ) : (
              <div className="aspect-video">
                <video
                  controls
                  autoPlay
                  className="w-full h-full rounded-lg"
                  src={(GALLERY_ITEMS[selectedItem] as any).videoUrl}
                >
                  Your browser does not support the video tag.
                </video>
                <p className="text-white text-center mt-4">
                  {GALLERY_ITEMS[selectedItem].caption}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}