import { useState, useEffect } from "react";
import { Home, Image, MapPin, Phone, Menu, X } from "lucide-react";
import { Button } from "./ui/button";
import { SITE_CONFIG } from "../data/content";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? "bg-white shadow-md" : "bg-white/95 backdrop-blur-sm"
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-64">
          {/* Logo - 220px with INSIDE Glow Only */}
          <div className="flex items-center">
            <img 
              src={SITE_CONFIG.logo} 
              alt={SITE_CONFIG.siteName}
              className="h-55 w-auto object-contain logo-shine-header"
              style={{ height: '220px' }}
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <button
              onClick={() => scrollToSection("home")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection("gallery")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Gallery
            </button>
            <button
              onClick={() => scrollToSection("amenities")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Amenities
            </button>
            <button
              onClick={() => scrollToSection("booking")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Booking
            </button>
            <button
              onClick={() => scrollToSection("blog")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Blog
            </button>
            <button
              onClick={() => scrollToSection("location")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Location
            </button>
            <button
              onClick={() => scrollToSection("contact")}
              className="text-gray-700 hover:text-orange-600 transition-colors"
            >
              Contact
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-gray-700 hover:text-orange-600 transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>

          {/* Book Now Button */}
          <a
            href={`https://wa.me/${SITE_CONFIG.phone.replace(/\s+/g, '')}?text=Hi,%20I%20would%20like%20to%20book%20Kasarani%20Haven%20Suites`}
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:block"
          >
            <Button className="bg-orange-500 hover:bg-orange-600 text-white rounded-full px-6">
              Book Now
            </Button>
          </a>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <nav className="flex flex-col gap-3">
              <button
                onClick={() => scrollToSection("home")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Home
              </button>
              <button
                onClick={() => scrollToSection("gallery")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Gallery
              </button>
              <button
                onClick={() => scrollToSection("amenities")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Amenities
              </button>
              <button
                onClick={() => scrollToSection("booking")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Booking
              </button>
              <button
                onClick={() => scrollToSection("blog")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Blog
              </button>
              <button
                onClick={() => scrollToSection("location")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Location
              </button>
              <button
                onClick={() => scrollToSection("contact")}
                className="text-gray-700 hover:text-orange-600 transition-colors text-left py-2"
              >
                Contact
              </button>
              <a
                href={`https://wa.me/${SITE_CONFIG.phone.replace(/\s+/g, '')}?text=Hi,%20I%20would%20like%20to%20book%20Kasarani%20Haven%20Suites`}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2"
              >
                <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white rounded-full px-6">
                  Book Now
                </Button>
              </a>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}