import { Phone, Mail, MapPin, Clock, Facebook, Instagram, Youtube } from "lucide-react";
import { SITE_CONFIG } from "../data/content";

export function Contact() {
  return (
    <footer id="contact" className="bg-gray-900 text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <img 
                src={SITE_CONFIG.logo} 
                alt={SITE_CONFIG.siteName}
                className="h-16 w-auto object-contain brightness-0 invert"
              />
            </div>
            <p className="text-gray-400 mb-4">
              {SITE_CONFIG.slogan}
            </p>
            <p className="text-gray-400 italic">
              "City living, homely feeling."
            </p>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="mb-4 text-white">Contact Us</h3>
            <div className="space-y-3">
              <a
                href={`tel:${SITE_CONFIG.phone.replace(/\s+/g, '')}`}
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Phone className="w-5 h-5" />
                <span>{SITE_CONFIG.phone}</span>
              </a>
              <a
                href={`mailto:${SITE_CONFIG.email}`}
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Mail className="w-5 h-5" />
                <span>{SITE_CONFIG.email}</span>
              </a>
              <div className="flex items-start gap-3 text-gray-400">
                <MapPin className="w-5 h-5 flex-shrink-0 mt-1" />
                <span>{SITE_CONFIG.address}</span>
              </div>
              <div className="flex items-center gap-3 text-gray-400">
                <Clock className="w-5 h-5" />
                <span>Open 24/7</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="mb-4 text-white">Quick Links</h3>
            <div className="space-y-3">
              <a
                href="#home"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Home
              </a>
              <a
                href="#gallery"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Gallery
              </a>
              <a
                href="#amenities"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Amenities
              </a>
              <a
                href="#booking"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Booking
              </a>
              <a
                href="#blog"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Blog
              </a>
              <a
                href="#terms"
                className="block text-gray-400 hover:text-orange-400 transition-colors"
              >
                Terms & Conditions
              </a>
            </div>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="mb-4 text-white">Follow Us</h3>
            <div className="space-y-3">
              <a
                href={`https://www.instagram.com/${SITE_CONFIG.socialMedia.instagram.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Instagram className="w-5 h-5" />
                <span>{SITE_CONFIG.socialMedia.instagram}</span>
              </a>
              <a
                href={`https://www.${SITE_CONFIG.socialMedia.facebook}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Facebook className="w-5 h-5" />
                <span>Kasarani Haven Suites</span>
              </a>
              <a
                href={`https://www.${SITE_CONFIG.socialMedia.youtube}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <Youtube className="w-5 h-5" />
                <span>Kasarani Haven Suites</span>
              </a>
              <a
                href={`https://www.tiktok.com/${SITE_CONFIG.socialMedia.tiktok.replace('@', '')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-gray-400 hover:text-orange-400 transition-colors"
              >
                <svg
                  className="w-5 h-5"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z" />
                </svg>
                <span>{SITE_CONFIG.socialMedia.tiktok}</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col items-center gap-6">
            {/* Kasarani Haven Logo - 300px with INSIDE Glow Only */}
            <div className="mb-4">
              <img 
                src={SITE_CONFIG.logo} 
                alt={SITE_CONFIG.siteName}
                className="h-75 w-auto object-contain logo-shine-footer"
                style={{ height: '300px' }}
              />
            </div>
            
            <p className="text-gray-400 text-center">
              © 2025 {SITE_CONFIG.siteName}. All rights reserved.
            </p>
            
            {/* Jaxcel Branding */}
            <div className="flex flex-col items-center gap-3">
              <p className="text-gray-400 text-center">Website created by</p>
              <a
                href="https://jaxcel.com"
                target="_blank"
                rel="noopener noreferrer"
                className="group"
              >
                <div className="flex flex-col items-center gap-2 transition-transform group-hover:scale-105">
                  <img 
                    src={SITE_CONFIG.jaxcelLogo} 
                    alt="Jaxcel Digital Marketing"
                    className="h-12 w-auto object-contain"
                  />
                  <p className="text-orange-400 text-center">
                    Fuelling your success with smart marketing
                  </p>
                  <p className="text-gray-500 text-xs group-hover:text-orange-400 transition-colors">
                    Visit jaxcel.com
                  </p>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}