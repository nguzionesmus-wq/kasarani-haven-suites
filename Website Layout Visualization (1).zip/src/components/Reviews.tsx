import { useState } from "react";
import { Star, User, ThumbsUp } from "lucide-react";
import { Button } from "./ui/button";
import { Textarea } from "./ui/textarea";
import { Input } from "./ui/input";
import { Card } from "./ui/card";

interface Review {
  id: number;
  name: string;
  rating: number;
  date: string;
  comment: string;
  helpful: number;
}

const existingReviews: Review[] = [
  {
    id: 1,
    name: "Sarah M.",
    rating: 5,
    date: "November 8, 2025",
    comment: "Absolutely loved staying at Kasarani Haven Suites! The apartment was spotlessly clean, well-furnished, and the location is perfect. Just 15 minutes to CBD and close to everything. Highly recommend!",
    helpful: 12,
  },
  {
    id: 2,
    name: "James K.",
    rating: 5,
    date: "November 2, 2025",
    comment: "Great value for money! The host was very responsive and accommodating. The place has everything you need - WiFi, parking, kitchen. Will definitely come back.",
    helpful: 8,
  },
  {
    id: 3,
    name: "Linda W.",
    rating: 4,
    date: "October 25, 2025",
    comment: "Nice, quiet neighborhood and the apartment is exactly as shown in the photos. Perfect for a short stay. The bed was very comfortable!",
    helpful: 5,
  },
];

export function Reviews() {
  const [reviews, setReviews] = useState<Review[]>(existingReviews);
  const [showForm, setShowForm] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [name, setName] = useState("");
  const [comment, setComment] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating && name && comment) {
      const newReview: Review = {
        id: reviews.length + 1,
        name: name,
        rating: rating,
        date: new Date().toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        }),
        comment: comment,
        helpful: 0,
      };
      setReviews([newReview, ...reviews]);
      setName("");
      setComment("");
      setRating(0);
      setShowForm(false);
    }
  };

  const averageRating = (
    reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length
  ).toFixed(1);

  return (
    <section id="reviews" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Guest Reviews</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            See what our guests are saying about their experience at Kasarani
            Haven Suites
          </p>
        </div>

        {/* Overall Rating */}
        <div className="max-w-4xl mx-auto mb-12">
          <Card className="p-8">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="text-center md:text-left">
                <div className="flex items-center gap-2 mb-2 justify-center md:justify-start">
                  <span className="text-5xl text-gray-900">5.0</span>
                  <div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className="w-6 h-6 fill-orange-400 text-orange-400"
                        />
                      ))}
                    </div>
                    <p className="text-gray-600">
                      Based on {reviews.length} reviews
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href="https://share.google.com/vChLm9SrMEyYVVhgX"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button
                    variant="outline"
                    className="border-orange-500 text-orange-600 hover:bg-orange-50"
                  >
                    <Star className="w-4 h-4 mr-2 fill-orange-400" />
                    View on Google (5⭐)
                  </Button>
                </a>
                <Button
                  onClick={() => setShowForm(!showForm)}
                  className="bg-orange-500 hover:bg-orange-600 text-white"
                >
                  Write a Review
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Review Form */}
        {showForm && (
          <div className="max-w-4xl mx-auto mb-12 animate-in slide-in-from-top duration-300">
            <Card className="p-6">
              <h3 className="mb-4 text-gray-900">Share Your Experience</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block mb-2 text-gray-700">
                    Your Rating *
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(0)}
                        className="transition-transform hover:scale-110"
                      >
                        <Star
                          className={`w-8 h-8 ${
                            star <= (hoverRating || rating)
                              ? "fill-orange-400 text-orange-400"
                              : "text-gray-300"
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block mb-2 text-gray-700">
                    Your Name *
                  </label>
                  <Input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter your name"
                    required
                  />
                </div>

                <div>
                  <label className="block mb-2 text-gray-700">
                    Your Review *
                  </label>
                  <Textarea
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Tell us about your experience..."
                    rows={4}
                    required
                    className="resize-none"
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    type="submit"
                    className="bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    Submit Review
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowForm(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            </Card>
          </div>
        )}

        {/* Reviews List */}
        <div className="max-w-4xl mx-auto space-y-6">
          {reviews.map((review) => (
            <Card key={review.id} className="p-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                  <User className="w-6 h-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h4 className="text-gray-900">{review.name}</h4>
                      <p className="text-gray-500">{review.date}</p>
                    </div>
                    <div className="flex gap-1">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <Star
                          key={star}
                          className={`w-4 h-4 ${
                            star <= review.rating
                              ? "fill-orange-400 text-orange-400"
                              : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  <p className="text-gray-700 mb-3">{review.comment}</p>
                  <button className="flex items-center gap-2 text-gray-500 hover:text-orange-600 transition-colors">
                    <ThumbsUp className="w-4 h-4" />
                    <span>Helpful ({review.helpful})</span>
                  </button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}