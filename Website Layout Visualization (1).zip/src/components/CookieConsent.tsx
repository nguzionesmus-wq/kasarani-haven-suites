import { useState, useEffect } from "react";
import { X, Cookie } from "lucide-react";
import { Button } from "./ui/button";

export function CookieConsent() {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem("cookie-consent");
    if (!consent) {
      // Show banner after a short delay
      setTimeout(() => setShowBanner(true), 1000);
    }
  }, []);

  const handleAccept = () => {
    localStorage.setItem("cookie-consent", "accepted");
    setShowBanner(false);
  };

  const handleReject = () => {
    localStorage.setItem("cookie-consent", "rejected");
    setShowBanner(false);
  };

  if (!showBanner) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 p-4 animate-in slide-in-from-bottom duration-500">
      <div className="container mx-auto max-w-5xl">
        <div className="bg-white rounded-xl shadow-2xl border border-gray-200 p-6">
          <div className="flex items-start gap-4">
            <div className="flex-shrink-0">
              <Cookie className="w-8 h-8 text-orange-500" />
            </div>
            <div className="flex-1">
              <h3 className="mb-2 text-gray-900">We value your privacy</h3>
              <p className="text-gray-600 mb-4">
                We use cookies to enhance your browsing experience, serve
                personalized content, and analyze our traffic. By clicking
                "Accept All", you consent to our use of cookies. Read our{" "}
                <button
                  onClick={() => {
                    const termsSection = document.getElementById("terms");
                    if (termsSection) {
                      termsSection.scrollIntoView({ behavior: "smooth" });
                    }
                  }}
                  className="text-orange-600 hover:underline"
                >
                  Terms & Conditions
                </button>{" "}
                for more information.
              </p>
              <div className="flex flex-wrap gap-3">
                <Button
                  onClick={handleAccept}
                  className="bg-orange-500 hover:bg-orange-600 text-white"
                >
                  Accept All
                </Button>
                <Button
                  onClick={handleReject}
                  variant="outline"
                  className="border-gray-300 text-gray-700 hover:bg-gray-50"
                >
                  Reject All
                </Button>
              </div>
            </div>
            <button
              onClick={handleReject}
              className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
