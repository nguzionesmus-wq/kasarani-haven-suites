import { ArrowLeft, MapPin, DollarSign, Clock, ExternalLink } from "lucide-react";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface RestaurantBlogPostProps {
  onBack: () => void;
}

const restaurants = [
  {
    name: "K'Osewe Ranalo Foods",
    location: "Kasarani - Along Thika Road",
    priceRange: "KSh 300 - 800",
    description: "Authentic Kenyan cuisine at its best! Famous for their fish dishes and traditional meals. The atmosphere is casual and welcoming, perfect for a hearty lunch or dinner without breaking the bank.",
    specialties: ["Fried Tilapia", "Ugali", "Sukuma Wiki", "Traditional Kenyan Dishes"],
    hours: "9:00 AM - 10:00 PM Daily",
    link: "https://www.google.com/maps/search/K'Osewe+Ranalo+Foods+Kasarani",
    image: "https://images.unsplash.com/photo-1730250619893-91982f0519b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlyb2JpJTIwcmVzdGF1cmFudCUyMGRpbmluZ3xlbnwxfHx8fDE3NjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Java House - Thika Road Mall",
    location: "Thika Road Mall (10 mins from Kasarani)",
    priceRange: "KSh 500 - 1,500",
    description: "A Kenyan favorite offering a mix of local and international cuisine. Great coffee, comfortable seating, and free Wi-Fi make it perfect for work meetings or casual hangouts.",
    specialties: ["Coffee & Pastries", "Burgers", "Breakfast All Day", "Salads"],
    hours: "7:00 AM - 10:00 PM Daily",
    link: "https://www.javahouseafrica.com/",
    image: "https://images.unsplash.com/photo-1567600175325-3573c56bee05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDF8fHx8MTc2Mjk0NjgyMHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Chicken Inn - Kasarani",
    location: "Kasarani Shopping Center",
    priceRange: "KSh 400 - 900",
    description: "Fast food done right! Southern fried chicken with a Kenyan twist. Great for quick, delicious meals that won't strain your wallet. Family meals available.",
    specialties: ["Fried Chicken", "Burgers", "Chips & Wings", "Family Packs"],
    hours: "8:00 AM - 11:00 PM Daily",
    link: "https://www.chickeninn.co.ke/",
    image: "https://images.unsplash.com/photo-1506267594256-7667b0040d31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZmZvcmRhYmxlJTIwcmVzdGF1cmFudCUyMGZvb2R8ZW58MXx8fHwxNjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Art Caffe - Garden City Mall",
    location: "Garden City Mall, Thika Road",
    priceRange: "KSh 600 - 1,800",
    description: "Upscale yet affordable dining experience. Beautiful ambiance with a diverse menu featuring Italian, Asian, and local favorites. Perfect for special occasions or business lunches.",
    specialties: ["Pasta", "Pizza", "Steaks", "International Cuisine"],
    hours: "7:30 AM - 10:30 PM Daily",
    link: "https://www.artcaffe.co.ke/",
    image: "https://images.unsplash.com/photo-1567600175325-3573c56bee05?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3p5JTIwcmVzdGF1cmFudCUyMGludGVyaW9yfGVufDF8fHx8MTc2Mjk0NjgyMHww&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Mama Oliech Restaurant",
    location: "Multiple Locations - Nearest at City Centre",
    priceRange: "KSh 400 - 1,000",
    description: "Legendary for their fish! A Nairobi institution serving delicious traditional meals. The fish is fresh, perfectly prepared, and comes with generous portions of sides.",
    specialties: ["Grilled Fish", "Fried Fish", "Ugali", "Traditional Sides"],
    hours: "11:00 AM - 9:00 PM Daily",
    link: "https://www.google.com/maps/search/Mama+Oliech+Restaurant+Nairobi",
    image: "https://images.unsplash.com/photo-1730250619893-91982f0519b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlyb2JpJTIwcmVzdGF1cmFudCUyMGRpbmluZ3xlbnwxfHx8fDE3NjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
  {
    name: "Njugu Karanga Joint - Local Favorite",
    location: "Kasarani - Near Haven Suites",
    priceRange: "KSh 200 - 500",
    description: "The best kept secret in Kasarani! Affordable local meals, generous portions, and friendly service. Try their nyama choma on weekends!",
    specialties: ["Nyama Choma", "Mukimo", "Githeri", "Local Dishes"],
    hours: "8:00 AM - 10:00 PM Daily",
    link: "https://www.google.com/maps/search/restaurants+near+Kasarani+Nairobi",
    image: "https://images.unsplash.com/photo-1506267594256-7667b0040d31?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhZmZvcmRhYmxlJTIwcmVzdGF1cmFudCUyMGZvb2R8ZW58MXx8fHwxNjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
  },
];

export function RestaurantBlogPost({ onBack }: RestaurantBlogPostProps) {
  return (
    <section className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          <Button
            variant="ghost"
            onClick={onBack}
            className="mb-6 text-orange-600 hover:text-orange-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Blog
          </Button>

          {/* Header */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-2 mb-4">
              <span className="text-xs bg-orange-100 text-orange-600 px-3 py-1 rounded-full">
                Food & Dining
              </span>
              <span className="text-xs bg-orange-100 text-orange-600 px-3 py-1 rounded-full">
                Budget-Friendly
              </span>
              <span className="text-xs bg-orange-100 text-orange-600 px-3 py-1 rounded-full">
                Local Guide
              </span>
            </div>
            <h1 className="mb-4 text-gray-900">
              Best Restaurants to Relax Around Nairobi at Affordable Prices
            </h1>
            <div className="flex items-center gap-4 text-gray-500">
              <span>By Kasarani Haven Team</span>
              <span>•</span>
              <span>November 12, 2025</span>
              <span>•</span>
              <span>8 min read</span>
            </div>
          </div>

          {/* Featured Image */}
          <div className="mb-8 rounded-xl overflow-hidden">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1730250619893-91982f0519b0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuYWlyb2JpJTIwcmVzdGF1cmFudCUyMGRpbmluZ3xlbnwxfHx8fDE3NjMwNDAzNTZ8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Nairobi Restaurants"
              className="w-full h-[400px] object-cover"
            />
          </div>

          {/* Introduction */}
          <div className="prose max-w-none mb-12">
            <p className="text-gray-700 mb-4">
              Looking for great places to eat around Nairobi without breaking the bank? 
              Whether you're staying at Kasarani Haven Suites or exploring the city, 
              we've compiled a list of the best affordable restaurants where you can 
              relax, enjoy delicious food, and get great value for your money.
            </p>
            <p className="text-gray-700 mb-4">
              From authentic Kenyan cuisine to international favorites, these restaurants 
              offer excellent food, pleasant ambiance, and prices that won't strain your 
              wallet. Perfect for solo travelers, couples, families, and business guests!
            </p>
            <div className="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6">
              <p className="text-gray-700">
                <strong>Note:</strong> All restaurants listed below are real establishments 
                in Nairobi. We've provided direct links to their locations and websites. 
                Prices and hours are approximate and may vary. We recommend calling ahead 
                or checking their social media for the most current information.
              </p>
            </div>
          </div>

          {/* Restaurants List */}
          <div className="space-y-12">
            {restaurants.map((restaurant, index) => (
              <div
                key={index}
                className="bg-gray-50 rounded-xl overflow-hidden border border-gray-200 hover:shadow-lg transition-shadow"
              >
                <div className="grid md:grid-cols-2 gap-0">
                  <div className="aspect-[4/3] md:aspect-auto">
                    <ImageWithFallback
                      src={restaurant.image}
                      alt={restaurant.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="mb-3 text-gray-900">{restaurant.name}</h3>
                    
                    <div className="space-y-3 mb-4">
                      <div className="flex items-start gap-2 text-gray-600">
                        <MapPin className="w-5 h-5 flex-shrink-0 mt-0.5 text-orange-500" />
                        <span>{restaurant.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <DollarSign className="w-5 h-5 flex-shrink-0 text-orange-500" />
                        <span className="text-orange-600">
                          {restaurant.priceRange}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-gray-600">
                        <Clock className="w-5 h-5 flex-shrink-0 text-orange-500" />
                        <span>{restaurant.hours}</span>
                      </div>
                    </div>

                    <p className="text-gray-700 mb-4">{restaurant.description}</p>

                    <div className="mb-4">
                      <p className="text-gray-900 mb-2">Must Try:</p>
                      <div className="flex flex-wrap gap-2">
                        {restaurant.specialties.map((specialty, idx) => (
                          <span
                            key={idx}
                            className="text-xs bg-white border border-orange-200 text-orange-700 px-2 py-1 rounded"
                          >
                            {specialty}
                          </span>
                        ))}
                      </div>
                    </div>

                    <a
                      href={restaurant.link}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                        View Location & Details
                        <ExternalLink className="w-4 h-4 ml-2" />
                      </Button>
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Conclusion */}
          <div className="mt-12 bg-orange-50 rounded-xl p-8 border border-orange-100">
            <h3 className="mb-4 text-gray-900">Final Thoughts</h3>
            <p className="text-gray-700 mb-4">
              Nairobi offers an incredible variety of affordable dining options 
              that don't compromise on quality or experience. Whether you're 
              craving traditional Kenyan flavors or international cuisine, these 
              restaurants near Kasarani and around Nairobi provide excellent 
              value for money.
            </p>
            <p className="text-gray-700 mb-6">
              After a great meal, come back and relax at Kasarani Haven Suites - 
              your comfortable home away from home, just minutes from all these 
              fantastic dining spots!
            </p>
            <a
              href="#booking"
              onClick={(e) => {
                e.preventDefault();
                onBack();
                setTimeout(() => {
                  const element = document.getElementById("booking");
                  if (element) {
                    element.scrollIntoView({ behavior: "smooth" });
                  }
                }, 100);
              }}
            >
              <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                Book Your Stay at Kasarani Haven Suites
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}