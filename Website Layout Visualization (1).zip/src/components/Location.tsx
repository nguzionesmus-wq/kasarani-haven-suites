import { MapPin, Car, ShoppingBag, Clock, Navigation } from "lucide-react";
import { Button } from "./ui/button";
import { SITE_CONFIG } from "../data/content";

export function Location() {
  return (
    <section id="location" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="mb-4 text-gray-900">Perfect Location</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Conveniently located in Clayworks, Kasarani — perfectly positioned
            for both business and leisure.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          {/* Location Info */}
          <div className="space-y-6">
            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="mb-2 text-gray-900">Our Address</h3>
                  <p className="text-gray-700">
                    {SITE_CONFIG.address}
                    <br />
                    Coordinates: {SITE_CONFIG.coordinates}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <div className="flex items-start gap-4">
                <Navigation className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                <div className="flex-1">
                  <h3 className="mb-2 text-gray-900">Get Directions</h3>
                  <p className="text-gray-700 mb-3">
                    Navigate easily to our location using Google Maps
                  </p>
                  <a
                    href={SITE_CONFIG.googleMapsDirections}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                      Open in Google Maps
                    </Button>
                  </a>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <div className="flex items-start gap-4">
                <Car className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="mb-2 text-gray-900">Distance to CBD</h3>
                  <p className="text-gray-700">
                    Only 15 minutes drive to Nairobi Central Business District
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <div className="flex items-start gap-4">
                <ShoppingBag className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="mb-2 text-gray-900">Nearby Amenities</h3>
                  <ul className="text-gray-700 space-y-1">
                    <li>• Bars & Restaurants</li>
                    <li>• Supermarkets & Shops</li>
                    <li>• Car Wash Services</li>
                    <li>• Laundry Mart</li>
                    <li>• Public Transport Access</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="bg-orange-50 p-6 rounded-xl border border-orange-100">
              <div className="flex items-start gap-4">
                <Clock className="w-6 h-6 text-orange-600 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="mb-2 text-gray-900">Check-in Flexibility</h3>
                  <p className="text-gray-700">
                    We offer flexible check-in times. Contact us to arrange your
                    arrival.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Map */}
          <div className="h-[600px] rounded-xl overflow-hidden shadow-xl border border-gray-200">
            <iframe
              src="https://www.google.com/maps?q=-1.212250,36.909972&hl=es;z=14&output=embed"
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Kasarani Haven Suites Location"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
}