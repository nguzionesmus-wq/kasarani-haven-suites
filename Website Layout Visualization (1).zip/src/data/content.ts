// Easy content management - Edit images and content here
import livingRoom1 from "figma:asset/0b9531c3cf20c79cf2ec9c12158de280d1715924.png";
import livingRoom2 from "figma:asset/b065973453a9fd018c9688c9d92d2994273f6ef2.png";
import seatingRoom from "figma:asset/146f31d6b08f094ee9844f28d2ce6b8c2d18bbf1.png";
import buildingExterior from "figma:asset/5e2d3ef2f081d965a2b7d16722a3d4a15ddacbcb.png";
import bedroom from "figma:asset/70209c0336d603f7973361950aea78697f187809.png";
import hallway from "figma:asset/68b12a618dd983747414a3dda01c6a959adc0939.png";
import kitchen from "figma:asset/38c84341396439f90571944e77745be63f1a9b1c.png";
import bathroom from "figma:asset/268c1c38e88c70f50a1d48e9f1837be0582bf027.png";
import stove from "figma:asset/64dddeb63f631ade118a2224dccecc848c3b4ca5.png";
import logo from "figma:asset/a59e1f6cbbb354d4de06907c0dc333a4f37f752b.png";
import jaxcelLogo from "figma:asset/1fb97691d9381e76979bfd1451183bfb5ba20811.png";

export const SITE_CONFIG = {
  siteName: "Kasarani Haven Suites",
  slogan: "A homely escape in the heart of Kasarani.",
  phone: "+254 727 832649",
  email: "info@kasaranihavensuites.com",
  address: "Clayworks, Kasarani, Nairobi",
  coordinates: "1°12'44.1\"S 36°54'35.9\"E",
  googleMapsDirections: "https://share.google.com/vChLm9SrMEyYVVhgX",
  logo: logo,
  jaxcelLogo: jaxcelLogo,
  socialMedia: {
    instagram: "@kasaranihavensuites",
    facebook: "facebook.com/kasaranihavensuites",
    tiktok: "@kasaranihaven",
    youtube: "youtube.com/@kasaranihavensuites",
  },
};

// HERO SECTION - Add your hero images here
export const HERO_IMAGES = [
  {
    src: seatingRoom,
    alt: "Kasarani Haven Suites - Elegant Seating Room",
  },
];

// GALLERY - Add your gallery images and videos here
export const GALLERY_ITEMS = [
  {
    type: "image" as const,
    src: livingRoom1,
    caption: "Spacious Living Room with Smart TV",
  },
  {
    type: "image" as const,
    src: livingRoom2,
    caption: "Comfortable Seating Area",
  },
  {
    type: "image" as const,
    src: seatingRoom,
    caption: "Elegant Blue Sofa Seating Room",
  },
  {
    type: "image" as const,
    src: bedroom,
    caption: "Cozy Bedroom with Comfortable Bed",
  },
  {
    type: "image" as const,
    src: kitchen,
    caption: "Clean Modern Kitchen with Sink",
  },
  {
    type: "image" as const,
    src: stove,
    caption: "Modern Gas Cooker with Fresh Flowers",
  },
  {
    type: "image" as const,
    src: bathroom,
    caption: "Modern Bathroom with Shower and Toilet",
  },
  {
    type: "image" as const,
    src: hallway,
    caption: "Bright Hallway with Mirror",
  },
  {
    type: "image" as const,
    src: buildingExterior,
    caption: "Building Exterior - Clayworks, Kasarani",
  },
  
  // 🎬 VIDEO UPLOAD - FOLLOW THESE STEPS:
  // ========================================
  // 
  // 1. UPLOAD YOUR VIDEO TO GOOGLE DRIVE:
  //    - Go to drive.google.com
  //    - Click "New" → "File upload"
  //    - Select your property video
  //    - Wait for upload to complete
  //
  // 2. MAKE IT SHAREABLE:
  //    - Right-click the video in Google Drive
  //    - Click "Share"
  //    - Change "Restricted" to "Anyone with the link"
  //    - Click "Copy link"
  //
  // 3. CONVERT THE LINK:
  //    Your link looks like: https://drive.google.com/file/d/ABC123XYZ/view
  //    Take the ID (ABC123XYZ) and create:
  //    https://drive.google.com/uc?export=download&id=ABC123XYZ
  //
  // 4. PASTE BELOW:
  //    Replace "YOUR_VIDEO_URL_HERE" with your converted link
  //
  // 5. SAVE THIS FILE - Your video will appear in the gallery!
  //
  {
    type: "video" as const,
    videoUrl: "https://drive.google.com/uc?export=download&id=17q3rDa5Aaaq3RbdWLJ9B2Ja1Aolo2-u2",
    thumbnail: seatingRoom,
    caption: "Virtual Tour of Kasarani Haven Suites",
  },
];

// SEO Keywords
export const SEO_KEYWORDS = [
  "best airbnb in kasarani",
  "kasarani accommodation",
  "airbnb nairobi",
  "kasarani haven suites",
  "short stay kasarani",
  "furnished apartment kasarani",
  "airbnb near nairobi cbd",
  "clayworks kasarani",
  "affordable airbnb nairobi",
];

export const SEO_DESCRIPTION =
  "Discover the best Airbnb in Kasarani! Kasarani Haven Suites offers fully furnished 1-bedroom apartments with free parking, Wi-Fi, and easy access to Nairobi CBD. Book your stay from KSh 3,000/night.";