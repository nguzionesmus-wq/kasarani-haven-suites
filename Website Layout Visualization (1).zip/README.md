
  # Website Layout Visualization

  This is a code bundle for Website Layout Visualization. The original project is available at https://www.figma.com/design/ubJmuO3fe4Dm7Ys4wvjVQc/Website-Layout-Visualization.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  